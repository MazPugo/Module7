import requests, csv
response = requests.get("http://api.nbp.pl/api/exchangerates/tables/C?format=json")
data = response.json()
data2 = data[0]
R = data2["rates"]
# R0 = R[0]
# X=R0.keys()

header=[]# initialize an empty list for header
info=[] # initialize an empty list for data(info)

for key, value in R[0].items(): # retrieve key (header) from the dictionnary R[0] and add it into the list header
    header.append(key)

for i in range(len(R)):
      col=[]
      for key, value in R[i].items(): # retrieve value (data) from the dictionnary R[i] and add it into the list info
           col.append(value)
      info.append(col)           

with open('currency.csv', 'w', encoding='UTF8', newline='') as f: # create a csv file currency,
#we use the writerows() method write multiple rows into the csv file: currency
    writer = csv.writer(f)

    # write the header
    writer.writerow(header)

    # write multiple rows
    writer.writerows(info)
    
